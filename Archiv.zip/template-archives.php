<?php

/* Template Name: Archive Template */

/* 
 * Uses the same content structure as the singular.php template,
 * but with the archives content conditionally output.
 */

get_template_part( 'singular' );