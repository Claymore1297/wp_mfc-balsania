<?php if ( is_active_sidebar( 'sidebar' ) ) : ?>

	<div class="sidebar right" role="complementary">
		<?php dynamic_sidebar( 'sidebar' ); ?>
	</div><!-- .sidebar -->
	
<?php endif; ?>